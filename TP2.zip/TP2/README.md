# KNN-Sentiment: TP2 de Métodos Numéricos

## Instrucciones

En `data/` están los datasets. Usaremos `imdb_small.csv` (6K de train, 6K de test).

En `src/` está el código de C++, en particular en `src/sentiment.cpp` está el entrypoint de pybind.

En `notebooks/` hay ejemplos para correr partes del TP usando sklearn y usando la implementación en C++. 
ATENCION: ¡¡Además alli se encuentra el codigo utilizado para la experimentación!!

Necesitamos bajar las librerías `pybind` y `eigen` (el "numpy" de C++), para eso bajamos los submódulos como primer paso.

Versión de Python >= 3.6.5


## Creación de un entorno virtual de python

### Con pyenv

```
curl https://pyenv.run | bash
```

Luego, se sugiere agregar unas líneas al bashrc. Hacer eso, **REINICIAR LA CONSOLA** y luego...

```
pyenv install 3.6.5
pyenv global 3.6.5
pyenv virtualenv 3.6.5 tp2
```

En el directorio del proyecto

```
pyenv activate tp2
```

### Directamente con python3
```
python3 -m venv tp2
source tp2/bin/activate
```

### Con Conda
```
conda create --name tp2 python=3.6.5
conda activate tp2
```

## Instalación de las depencias
```
pip install -r requirements.txt
```

## Correr notebooks de jupyter

```
cd notebooks
jupyter lab
```
o  notebook
```
jupyter notebook
```


## Compilación
Ejecutar las dos primeras celda del notebook `knn.ipynb` o seguir los siguientes pasos:


- Compilar el código C++ en un módulo de python
```
mkdir build
cd build
rm -rf *
cmake -DPYTHON_EXECUTABLE="$(which python)" -DCMAKE_BUILD_TYPE=Release ..
```
- Al ejecutar el siguiente comando se compila e instala la librería en el directorio `notebooks`
```
make install
```

##Ejecución

Los archivos a ejecutar se encuentran en la carpeta bin
	bin/classify.py: Script que, dado un conjunto de reseñas, las clasifica en positivas o negativas. 
   	 bin/evaluate.py: Script que, dado un archivo de reseñas predecidas por nuestro sistema y uno de etiquetas "verdaderas", evalúa el accuracy resultante.
    

Para ejecutar el programa, utilizaremos el archivo calssify.py que en nuestro caso esta configurado inicial,ente para usar PCA y con valores de
alpha=450 y k=2000. Hemos visto en el informe que estos son los mejores valores que hemos encontrado.
 Estos se puede cambiar para ejecutar el programa de otra forma. Se ejecutan de la siguiente forma


python bin/classify.py ARCHIVO_DE_TEST.csv ARCHIVO_DE_ SALIDA.out
Ejemplo: python bin/classify.py test_sample.csv test_sample.out

Se puede verificar la accuracy de la siguiente manera 

python bin/evaluate.py RESULTADOS_PREDECIDOS.out RESULTADOSVERDADEROS
Ejemplo: python bin/evaluate.py test_sample.out test_sample.true

##COMENTARIOS
 En la carpeta src se encuentra el codigo realizado en C++
la carpeta de data contiene el dataset utilizado para entrenar a nuestro algoritmo.
La carpeta eigen contiene dicha libreria, utilizada en C++.
La carpeta notebook tiene archivos .csv resultado de experimentaciones detalladas en el knn.ipynb
La carpeta pybind11 contiene archivos utilizados para crear el entorno virtual de python.




